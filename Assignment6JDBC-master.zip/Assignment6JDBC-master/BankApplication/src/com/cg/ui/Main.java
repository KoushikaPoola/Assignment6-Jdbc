package com.cg.user;
import java.util.Scanner;

import com.cg.beans.Account;
import com.cg.beans.Loan;
import com.cg.dao.IDao;
import com.cg.dao.DaoImp;
import com.cg.service.IService;
import com.cg.service.ServiceImp;

public class Main {

	public static void main(String[] args) {
		String name, id, address, loanid, loantype;
		double deposit, withdraw, loanamount;
		
		IDao dao = new DaoImp();
		IService service = new ServiceImp();

		while (true) {
			System.out.println("1. Create Account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Apply Loan");
			System.out.println("5. Show Account Details");
			System.out.println("6. Pay Loan");
			System.out.println("7. Show Loan Details");
			System.out.println("8. Exit");

			Scanner sc = new Scanner(System.in);
			System.out.println("enter your choice");
			int choice = sc.nextInt();

			switch (choice) {

			case 1: {
				while (true) {
					System.out.println("Enter your name (First letter must be in UpperCase)");
					name = sc.next();
					if (service.nameValidation(name)) {
						System.out.println("Enter account Id (eg. 1234567-ABCD");
						id = sc.next();
						if (service.idValidation(id)) {
							System.out.println("Enter address");
							address = sc.next();
							System.out.println("Enter deposit");
							deposit = sc.nextDouble();
							Account acct = new Account(id, name, address, deposit);
							dao.createAccount(acct);
							break;
						} else {
							System.out.println("Please enter valid Id");
						}
					} else
						System.out.println("Please enter valid name ");
				}
				break;
			}
			case 2: {
				System.out.println("Enter account Id and amount");
				id = sc.next();
				deposit = sc.nextDouble();
				System.out.println("Available balance after deposit is: "+ dao.deposit(id, deposit));
				break;
			}

			case 3: {
				System.out.println("Enter account Id and amount");
				id = sc.next();
				withdraw = sc.nextDouble();
				System.out.println("Available balance after withdrawl is: " +dao.withdraw(id, withdraw));
				break;
			}
			case 4: {
				System.out.println("Enter account Id");
				id = sc.next();
				System.out.println("Enter Loan Id");
				loanid = sc.next();
				if (id.equals(loanid)) {
					System.out.println("Enter Loan Type :");
					loantype = sc.next();
					System.out.println("Enter loan amount");
					loanamount = sc.nextDouble();
					Loan l = new Loan(loanid, loantype, loanamount);
					dao.applyLoan(l);
					break;
				} else
					System.out.println("Enter valid Loan Id");
				break;
			}

			case 5: {
				System.out.println("Enter account Id");
				id = sc.next();
				Account at = dao.getAccountDetails(id);
				System.out.println("Your account details are: ");
				System.out.println(at);
				break;

			}

			case 6: {
				System.out.println("Enter account Id");
				id = sc.next();
				System.out.println("Enter Loan Id");
				loanid = sc.next();
				if (id.equals(loanid)) {
					System.out.println("Enter amount to repay");
					loanamount = sc.nextDouble();
					System.out.println("Available Balance after repaying loan is : " + dao.payLoan(loanid, loanamount));
					break;
				}
			}
			case 7:{
				System.out.println("Enter loan Id");
				loanid = sc.next();
				Loan loan = dao.getLoanDetails(loanid);
				System.out.println("Loan Details are: ");
				System.out.println(loan);
				break;
                        }
	                case 8: {
				System.out.println("Thank you!");
                                sc.close();
				break;
			}
			
			default:
				System.out.println("Please enter correct choice");
                                
			}
		}
	}
}
