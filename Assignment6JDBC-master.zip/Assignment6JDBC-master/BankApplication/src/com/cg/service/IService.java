package com.bank.service;


import com.bank.beans.*;

public interface IService {

	public boolean idValidation(String id);
	public boolean nameValidation(String name);

}
