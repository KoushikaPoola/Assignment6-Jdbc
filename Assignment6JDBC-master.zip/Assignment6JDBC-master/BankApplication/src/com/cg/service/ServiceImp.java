package com.cg.service;
import java.util.regex.Pattern;
import com.cg.service.IService;

public class ServiceImp implements IService {
      
        @Override
        public boolean idValidation(String id) {
		if (Pattern.matches("^[1-9]{7}-[A-Z]{4}$", id)) {
			return true;
		} else
			return false;
	}
	
        @Override
	public boolean nameValidation(String name) {
		if (Pattern.matches("^[A-Z]{1}[a-z]{2,}$", name)) {
			return true;
		} else {
			return false;
		}
	}

}
