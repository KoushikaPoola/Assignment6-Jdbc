package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.beans.Account;
import com.cg.beans.Loan;
import com.cg.dao.IDao;

public class DaoImp implements IDao {

	PreparedStatement ps = null;
	PreparedStatement ps1 = null;
	PreparedStatement pst = null;
	Connection con = null;

        @Override
	public void createAccount(Account account) {
		String name = account.getAccountName();
		String id = account.getAccountId();
		String address = account.getAddress();
		double deposit = account.getDepositAmount();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
			ps = con.prepareStatement("insert into Account values(?,?,?,?)");
			ps.setString(1, id);
			ps.setString(2, name);
			ps.setString(3, address);
			ps.setDouble(4, deposit);
                        int result = ps.executeUpdate();

			if (result == 1) {
				System.out.println("Account created successfully!");
			}

			con.close();

		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
	}
        @Override
	public double deposit(String id, double deposit) {
		double availBalance;
		try {
			if (deposit > 0) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
                                pst = con.prepareStatement("select deposit amount from account");
				ResultSet rs = pst.executeQuery();
                                ps = con.prepareStatement("update account set deposit= ? where id=?");

				if (rs.next()) {
					double bal = rs.getDouble("deposit");
					availBalance = bal + deposit;
                                        ps.setDouble(1, availBalance);
					ps.setString(2, id);

					int result = ps.executeUpdate();

					if (result > 0) {
						System.out.println("Money deposited scucessfully!");
						return availBalance;
					}
					con.close();
				}
			}
		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}
        @Override
	public double withdraw(String id, double withdraw) {
		double availBalance;
		try {
			if (withdraw > 0) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
				pst = con.prepareStatement("select deposit amount from account");
				ResultSet rs = pst.executeQuery();
				ps = con.prepareStatement("update account set deposit= ? where id=?");

				if (rs.next()) {
					double bal = rs.getDouble("deposit");
					availBalance = bal - withdraw;
					ps.setDouble(1, availBalance);
					ps.setString(2, id);
					int result = ps.executeUpdate();

					if (result > 0) {
						System.out.println("Money withdrawn successfully! ");
						return availBalance;
					}
					con.close();
				}
			}
		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}
        @Override
	public void applyLoan(Loan loan) {
		String loanid = loan.getLoanId();
		String loantype = loan.getLoanType();
		double loanamount = loan.getLoanAmount();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
			ps = con.prepareStatement("insert into Loan values(?,?,?)");
			ps.setString(1, loanid);
			ps.setString(2, loantype);
			ps.setDouble(3, loanamount);
                        int result = ps.executeUpdate();

			if (result == 1) {
				System.out.println("Loan applied successfully!");
			}

			con.close();

		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
	}
        @Override
	public double payLoan(String loanid, double loanamount) {
		double availBalance;
		try {
			if (loanamount > 0) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
                                pst = con.prepareStatement("select loan.loanAmount, account.deposit from loan inner join account on loan.loanId = account.id");
				ResultSet rs = pst.executeQuery();
                                ps = con.prepareStatement("update account set deposit = ?  where id= ?");
				ps1 = con.prepareStatement("update loan set loanAmount= ? where loanId = ?");

				if (rs.next()) {
					double bal = rs.getDouble("deposit");
					availBalance = bal - loanamount;
                                        double bal1 = rs.getDouble("loanAmount");
					double loanRem = bal1 - loanamount;

					ps.setDouble(1, availBalance);
					ps.setString(2, loanid);
					ps1.setDouble(1, loanRem);
					ps1.setString(2, loanid);

					int result = ps.executeUpdate();
					int result1 = ps1.executeUpdate();

					if (result == 1) {
						System.out.println("Loan paid successfully! Remaining loan amount is: "+ loanRem);
						return availBalance;
					}
					con.close();
				}
			}
		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}
        @Override
	public Account getAccountDetails(String id) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
			ps = con.prepareStatement("select id, name, address, deposit from Account where id = ?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Account acct = new Account();
				acct.setAccountId(rs.getString("id"));
				acct.setAccountName(rs.getString("name"));
				acct.setAddress(rs.getString("address"));
				acct.setDepositAmount(rs.getDouble("deposit"));
				return acct;
			}
			con.close();
		} 
                catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}
        @Override
	public Loan getLoanDetails(String loanid) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1", "root", "kou123");
			ps = con.prepareStatement("select loanId, loanType, loanAmount from loan where loanId = ?");
			ps.setString(1, loanid);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Loan ln = new Loan();
				ln.setLoanId(rs.getString("loanId"));
				ln.setLoanType(rs.getString("loanType"));
				ln.setLoanAmount(rs.getDouble("loanAmount"));
				return ln;
			}
			con.close();
		}
                catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

}
