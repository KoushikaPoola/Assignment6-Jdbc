package com.bank.dao;

import com.bank.beans.Account;
import com.bank.beans.Loan;

public interface IDao {

	public void createAccount(Account account);
        public double deposit(String id, double deposit);
        public double withdraw(String id, double withdraw);
        public void applyLoan(Loan loan);
        public double payLoan(String loanid, double loanamount);
        public Account getAccountDetails(String id);
        public Loan getLoanDetails(String loanid) ;
	
}
